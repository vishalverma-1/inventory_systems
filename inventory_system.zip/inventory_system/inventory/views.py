from django.shortcuts import render
# inventory/views.py
from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.cache import cache
from .models import Item
from .serializers import ItemSerializer
import logging

logger = logging.getLogger(__name__)

class ItemViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    def create(self, request):
        serializer = ItemSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            logger.info('Item created successfully')
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def retrieve(self, request, pk=None):
        cached_item = cache.get(f'item_{pk}')
        if cached_item:
            return Response(cached_item)

        try:
            item = Item.objects.get(pk=pk)
            serializer = ItemSerializer(item)
            cache.set(f'item_{pk}', serializer.data)
            print(serializer.data,"uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu")
            logger.info(f'Item retrieved: {pk}')
            return Response(serializer.data)
        
        except Item.DoesNotExist:
            logger.error(f'Item not found: {pk}')
            return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)

    def update(self, request, pk=None):
        try:
            item = Item.objects.get(pk=pk)
            serializer = ItemSerializer(item, data=request.data)
            if serializer.is_valid():
                serializer.save()
                logger.info(f'Item updated: {pk}')
                cache.delete(f'item_{pk}')
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Item.DoesNotExist:
            logger.error(f'Item not found: {pk}')
            return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)

    def destroy(self, request, pk=None):
        try:
            item = Item.objects.get(pk=pk)
            item.delete()
            cache.delete(f'item_{pk}')
            logger.info(f'Item deleted: {pk}')
            return Response({'message': 'Item deleted successfully'}, status=status.HTTP_200_OK)
        except Item.DoesNotExist:
            logger.error(f'Item not found: {pk}')
            return Response({'error': 'Item not found'}, status=status.HTTP_404_NOT_FOUND)
